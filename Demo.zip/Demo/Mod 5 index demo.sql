USE [WideWorldImporters]
GO

CREATE TABLE [Warehouse].[ColdRoomTemperatures2]
(
	[ColdRoomTemperatureID] [bigint]  NOT NULL,
	[ColdRoomSensorNumber] [int] NOT NULL,
	[RecordedWhen] [datetime2](7) NOT NULL,
	[Temperature] [decimal](10, 2) NOT NULL,
	[ValidFrom] [datetime2](7) NOT NULL,
	[ValidTo] [datetime2](7)  NOT NULL,
)

CREATE INDEX [IX_Warehouse_ColdRoomTemperatures_ColdRoomSensorNumber] 
	ON [Warehouse].[ColdRoomTemperatures2]
	([ColdRoomSensorNumber] ASC)
GO

INSERT [Warehouse].[ColdRoomTemperatures2]
SELECT [ColdRoomTemperatureID]
      ,[ColdRoomSensorNumber]
      ,[RecordedWhen]
      ,[Temperature]
      ,[ValidFrom]
      ,[ValidTo]
  FROM [Warehouse].[ColdRoomTemperatures]
GO


SELECT * FROM sys.dm_db_index_physical_stats(db_id(), 