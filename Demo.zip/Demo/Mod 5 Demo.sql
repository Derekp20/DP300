USE AdventureWorksDW2017;

SELECT orderdate
    ,avg(salesAmount)
FROM FactResellerSales WHERE ShipDate = '2013-07-07'
GROUP BY orderdate;


--Reading an execution plan
USE AdventureWorks2017;

SELECT P.Name, Sum(SOD.LineTotal) as TotalSales
	,SOH.OrderDate�
FROM Production.Product P
	JOIN Sales.SalesOrderDetail SOD on SOD.ProductID = P.ProductID 
	JOIN Sales.SalesOrderHeader SOH on SOH.SalesOrderID = SOD.SalesOrderID
GROUP BY P.Name, SOH.OrderDate
ORDER BY TotalSales DESC


USE WideWorldImporters;

SELECT [stockItemName]
 ,[UnitPrice] * [QuantityPerOuter] AS CostPerOuterBox
 ,[QuantityonHand]
FROM [Warehouse].[StockItems] s
   JOIN [Warehouse].[StockItemHoldings] sh ON s.StockItemID = sh.StockItemID
ORDER BY CostPerOuterBox;

--Last query plan stats

SELECT * 
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st
CROSS APPLY sys.dm_exec_query_plan_stats(plan_handle) AS qps; 
GO


--Querying Wait stats
SELECT *
FROM sys.dm_os_wait_stats;


SELECT [wait_type] 
	,[waiting_tasks_count] 
	,[wait_time_ms] 
	,[wait_time_ms] / [waiting_tasks_count] AS [avg_wait_time_ms] 
	,[max_wait_time_ms] 
	,[signal_wait_time_ms] 
FROM sys.dm_os_wait_stats
WHERE waiting_tasks_count >0
ORDER BY [avg_wait_time_ms] DESC
