/**********************************
CREATING AZURE ELASTIC JOBS

1.	Create an Azure SQL Database of size S0 minimum

2.	Create an Azure Elastic Job, specify the database just created

3.	Create the Credentials in the target databases

4.	Create the Credentials in the Elastic Job Database

5.	Add a Target Group and Target servers to the group

6.	Create the job and job steps

7.	Manualy start the job and schedule the job

https://docs.microsoft.com/en-us/azure/azure-sql/database/elastic-jobs-tsql-create-manage

***********************************/

-- 3. Creating credentials in Target Server
-- Run on Target Server
CREATE LOGIN refreshcredential WITH PASSWORD= 'R`~W,q$+<x;2TY%]';
CREATE USER refreshcredential FROM LOGIN refreshcredential;

-- Job Credential on Target Server Master db
CREATE LOGIN jobcredential WITH PASSWORD='u@SfdAhwX_vC3JNM';

-- jobCredential User on Target Database
CREATE USER jobcredential FROM LOGIN jobcredential;

-- give permissions in the database
EXEC sp_addrolemember 'db_owner', 'jobcredential'



--4. Create the Credentials in the Elastic Job Database
-- Run on Elasticjobdb
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'C9aMeK<HZfj/!"R-';

CREATE DATABASE SCOPED CREDENTIAL refreshcredential
WITH IDENTITY = 'refreshcredential',
SECRET = 'R`~W,q$+<x;2TY%]'

CREATE DATABASE SCOPED CREDENTIAL jobcredential
WITH IDENTITY = 'jobcredential',
SECRET = 'u@SfdAhwX_vC3JNM'

-- Check the credentials
SELECT * FROM sys.database_scoped_credentials



--5. Add Target group and server
--Run on ElasticJobDB
EXEC jobs.sp_add_target_group 'DemoGroup'


-- Add a server target member (change servername place holder)
EXEC jobs.sp_add_target_group_member 'DemoGroup',
@target_type = 'SqlDatabase', --could be SQLServer (i.e. all databases on the server)
@database_name = 'dp300AdventureworksLT1',
--@refresh_credential_name='refreshcredential', --credential required to refresh the databases in server
@server_name='dp300elasticserver.database.windows.net'

--View the recently created target group and target group members
SELECT * FROM jobs.target_groups WHERE target_group_name='DemoGroup';
SELECT * FROM jobs.target_group_members WHERE target_group_name='DemoGroup';


-- 6. Create the job and job steps
-- Run on elasticJobDB

--Add job for demo123
EXEC jobs.sp_add_job @job_name='demo123', @description='Demo job'

-- Add job step for update statistics
EXEC jobs.sp_add_jobstep @job_name='demo123',
@command= 'EXEC dbo.IndexMaintenance',
@credential_name='jobcredential',
@target_group_name='DemoGroup'

--Check that job has been created
SELECT * FROM jobs.jobs WHERE job_name = 'demo123'



--7. Start the job and add a schedule
-- Run on elasticJobDB

EXEC jobs.sp_start_job 'demo123'

SELECT * FROM [jobs].[job_executions] order by start_time desc
GO

-- Cancel job execution with the specified job execution id
EXEC jobs.sp_stop_job '536BE14D-4D01-46DF-BD04-B2433941F1C4'


--Schedule the job to run daily at 22:00
DECLARE @schedule_start_time datetime2 = '2020-12-01 22:00:00'

EXEC jobs.sp_update_job
@job_name = 'demo123',
@enabled=1,
@schedule_interval_type='day',
@schedule_interval_count=1,
@schedule_start_time = @schedule_start_time 


GO

SELECT * FROM [jobs].[job_executions] order by start_time desc

GO


