--Mod 3 Demo 1

USE AdventureWorks;
GO

--Create a user in the database
CREATE USER [DP300User1] WITH PASSWORD = 'Pa55.w.rd';
GO

--Create a role in the database and add user
CREATE ROLE [SalesReader];
GO

ALTER ROLE [SalesReader] ADD MEMBER [DP300User1];
GO

--Grant permissions on the database
GRANT SELECT, EXECUTE ON SCHEMA::Sales TO [SalesReader];
GO


--Create a stored procedure using Product tables and sales tables
CREATE OR ALTER PROCEDURE Sales.DemoProc
as

SELECT P.Name, Sum(SOD.LineTotal) as TotalSales ,SOH.OrderDate
FROM Production.Product P
	INNER JOIN Sales.SalesOrderDetail SOD on SOD.ProductID = P.ProductID
	INNER JOIN Sales.SalesOrderHeader SOH on SOH.SalesOrderID = SOD.SalesOrderID
GROUP BY P.Name, SOH.OrderDate
ORDER BY TotalSales DESC;

GO



--Test as DP300User1
EXECUTE AS USER = 'DP300User1';

--try direct access to tables
SELECT P.Name, Sum(SOD.LineTotal) as TotalSales ,SOH.OrderDate
FROM Production.Product P
	INNER JOIN Sales.SalesOrderDetail SOD on SOD.ProductID = P.ProductID
	INNER JOIN Sales.SalesOrderHeader SOH on SOH.SalesOrderID = SOD.SalesOrderID
GROUP BY P.Name, SOH.OrderDate
ORDER BY TotalSales DESC;


--Execute the procedure
EXECUTE Sales.DemoProc;

--Revert to admin
REVERT;

/**********************************************************/

--Stored Proc with Dynamic SQL
ALTER PROCEDURE Sales.DemoProc
AS

DECLARE @sqlstring NVARCHAR(MAX)

SET @sqlstring = 'SELECT P.Name, Sum(SOD.LineTotal) as TotalSales ,SOH.OrderDate
FROM Production.Product P
INNER JOIN Sales.SalesOrderDetail SOD on SOD.ProductID = P.ProductID
INNER JOIN Sales.SalesOrderHeader SOH on SOH.SalesOrderID = SOD.SalesOrderID
GROUP BY P.Name, SOH.OrderDate'

EXECUTE sp_executesql @sqlstring
GO

--Test the procedure
EXECUTE Sales.DemoProc

--Test the procedure as DP300User1

EXECUTE AS USER = 'DP300User1'

EXECUTE Sales.DemoProc

REVERT;